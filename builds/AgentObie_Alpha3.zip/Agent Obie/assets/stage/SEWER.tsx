<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SEWER" tilewidth="8" tileheight="8">
 <image source="../img/tiles_sewer.png" width="40" height="48"/>
</tileset>
