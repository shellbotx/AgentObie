<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PLACEHOLDER" tilewidth="8" tileheight="8">
 <image source="../img/placeholder.png" width="16" height="32"/>
</tileset>
